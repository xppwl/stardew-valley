❀❀❀ 𝒉𝒐𝒘 𝒕𝒐 𝒖𝒔𝒆 𝒕𝒉𝒆 𝒎𝒐𝒅
╰─▸install SMAPI 
╰─▸install the requirements
╰─▸put the mod (and the requirements) in your Stardew Valley/Mods folder
╰─▸load the game

❀❀❀ 𝒄𝒓𝒆𝒅𝒊𝒕𝒔
╰─▸special thank you to 𝑵𝒂𝒏𝒐𝑰𝒔𝑵𝒐𝒕𝑹𝒐𝒃𝒐𝒕 for granting me permission to convert her mod and for adding variations.
➥➥➥ 𝑵𝒂𝒏𝒐𝑰𝒔𝑵𝒐𝒕𝑹𝒐𝒃𝒐𝒕's profile: https://www.nexusmods.com/users/62992811

❀❀❀ 𝒆𝒏𝒄𝒐𝒖𝒏𝒕𝒆𝒓𝒆𝒅 𝒂 𝒑𝒓𝒐𝒃𝒍𝒆𝒎 / 𝒃𝒖𝒈 ?
╰─▸if you think you have encountered a problem or a bug with this mod, then do the following: 
╰─▸go to Smapi Log Parser to record your issue. Follow their instructions. Make sure to COPY your smapi log URL.
╰─▸go to my mod page and report your issue in the 'BUGS' section. PASTE your smapi log URL.

➥➥➥ 𝑺𝒎𝒂𝒑𝒊 𝑳𝒐𝒈 𝑷𝒂𝒓𝒔𝒆𝒓: https://smapi.io/log
