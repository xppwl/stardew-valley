<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="z_spring_island_tilesheet_1" tilewidth="16" tileheight="16" tilecount="1280" columns="32">
 <image source="spring_island_tilesheet_1.png" width="512" height="640"/>
 <tile id="0">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="1">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="2">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="3">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="4">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="5">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="6">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="7">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="8">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="9">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="10">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="11">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="12">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="13">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="14">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="15">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="135">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="160">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="161">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="162">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="163">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="164">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="165">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="166">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="167">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="168">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="192">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="193">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="197">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="198">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="199">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="200">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="224">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="225">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="229">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="230">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="231">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="232">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="234">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="235">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="236">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="256">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="257">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="268">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="288">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="289">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="300">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="320">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="321">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="588">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="589">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="590">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="591">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="592">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="593">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="619">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="620">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="621">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="622">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="623">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="624">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="625">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="626">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="658">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="659">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="690">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="691">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
</tileset>
