<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="z_spring_beach" tilewidth="16" tileheight="16" tilecount="527" columns="17">
 <image source="spring_beach.png" width="272" height="496"/>
 <tile id="0">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="1">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="2">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="3">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="4">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="5">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="6">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="7">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="8">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="9">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="10">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="11">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="12">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="13">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="14">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="15">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="17">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="34">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="35">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="75">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="89">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="90">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="91">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="92">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="93">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="107">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="108">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="109">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="110">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="124">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="125">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="126">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="127">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="129">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="130">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="185">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="203">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="335">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="336">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="339">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="423">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="424">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="440">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="441">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="458">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="475">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
</tileset>
